﻿-- ======================================================================
-- Author:	Ankita Patel
-- Create date: 05-03-2014
-- Updated date: 10-04-2015
-- Description: Add products to Incremental_Solr_Product when add a new Store and new language is added and if language is updated
-- ======================================================================

DECLARE @pId int
DECLARE @sId int
DECLARE @lId int
DECLARE @IsDeleted bit

CREATE TABLE Temp(
ProductId [int],
StoreId [int],
LanguageId [int],
IsDeleted [bit])

DECLARE tempCursor CURSOR SCROLL FOR
 
SELECT p.Id,s.Id,l.Id FROM Store s, Product p, Language as l LEFT JOIN StoreMapping sm ON sm.EntityId = l.Id 
WHERE (l.LimitedToStores=1 AND s.Id IN (sm.StoreId) AND sm.EntityName='Language') OR l.LimitedToStores=0 	

OPEN tempCursor

FETCH FIRST FROM tempCursor
INTO @pId,@sId,@lId

WHILE @@fetch_status = 0   
 BEGIN     
    INSERT INTO Temp
	SELECT @pId,@sId,@lId,0
    
	INSERT INTO Incremental_Solr_Product
	SELECT @pId,1,0,GETDATE(),@sId,@lId
	WHERE NOT EXISTS (SELECT * FROM Incremental_Solr_Product WHERE ProductId = @pId AND StoreId=@sId AND LanguageId=@lId);

    FETCH NEXT FROM tempCursor
    INTO @pId,@sId, @lId;
 END
CLOSE tempCursor

DEALLOCATE tempCursor

DECLARE fetchCursor CURSOR SCROLL FOR 

SELECT ProductId,StoreId,LanguageId, IsDeleted FROM Incremental_Solr_Product

OPEN fetchCursor
FETCH FIRST FROM fetchCursor INTO @pId,@sId,@lId,@IsDeleted

WHILE @@fetch_status = 0
	
BEGIN

IF (SELECT count(*) FROM Temp WHERE ProductId=@pId AND StoreId=@sId AND LanguageId=@lId) >= 1
BEGIN	
	IF (SELECT count(*) FROM Temp WHERE ProductId=@pId AND StoreId=@sId AND LanguageId=@lId AND IsDeleted=@IsDeleted) = 0
	BEGIN
		UPDATE Incremental_Solr_Product SET IsDeleted=0 WHERE ProductId=@pId AND StoreId=@sId AND LanguageId=@lId
	END
END

ELSE 
	BEGIN
		UPDATE Incremental_Solr_Product SET IsDeleted=1 WHERE ProductId=@pId AND StoreId=@sId AND LanguageId=@lId
END
		
 FETCH NEXT FROM fetchCursor
    INTO @pId,@sId, @lId, @IsDeleted;
 END
CLOSE fetchCursor

DEALLOCATE fetchCursor

DROP TABLE Temp

UPDATE Incremental_Solr_Product SET IsDeleted = 1
WHERE ProductId IN (SELECT p.Id FROM Product AS p WHERE p.Published = 0 OR p.Deleted = 1 OR p.VisibleIndividually = 0) 