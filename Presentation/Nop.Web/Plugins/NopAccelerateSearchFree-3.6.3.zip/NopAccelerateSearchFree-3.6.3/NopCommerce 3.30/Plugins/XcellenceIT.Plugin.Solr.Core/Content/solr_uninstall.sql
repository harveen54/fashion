-- =============================================================================================
-- Author:		  Mayank Modi
-- Create date:   04-09-2015
-- Updated date:   04-30-2015
-- Description:	
				  -- Droppring all the tables/settings while uninstalling the core plugin
				  -- Removing Incremental_Solr_Products, ScheduleTask, ActivityLogType etc
-- =============================================================================================


-- Deleting incremental solr products from [Incremental_Solr_Product] table, but check if table exists or not before delete to overcome issue table doesn't exists
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'Incremental_Solr_Product'))
BEGIN
DROP TABLE [dbo].[Incremental_Solr_Product]
END


-- Deleting solr logs from [SolrLog] table, but check if table exists or not before delete to overcome issue table doesn't exists
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'SolrLog'))
BEGIN
DROP TABLE [dbo].[SolrLog]
END


-- Deleting scheduler setting from [ScheduleTask] table
Delete from [dbo].[ScheduleTask] Where Name like 'Solr IDI Process'


-- Deleting activity log setting from [ActivityLogType] table
Delete from [dbo].[ActivityLogType] Where SystemKeyword like 'SolrUtility';
Delete from [dbo].[ActivityLogType] Where SystemKeyword like 'SolrUtilityAPI';
Delete from [dbo].[ActivityLogType] Where SystemKeyword like 'AddSolrProduct';
Delete from [dbo].[ActivityLogType] Where SystemKeyword like 'AddSolrProductAPI';
Delete from [dbo].[ActivityLogType] Where SystemKeyword like 'UpdateSolrProductAPI';
Delete from [dbo].[ActivityLogType] Where SystemKeyword like 'DeleteSolrProduct';
Delete from [dbo].[ActivityLogType] Where SystemKeyword like 'DeleteSolrProductAPI';