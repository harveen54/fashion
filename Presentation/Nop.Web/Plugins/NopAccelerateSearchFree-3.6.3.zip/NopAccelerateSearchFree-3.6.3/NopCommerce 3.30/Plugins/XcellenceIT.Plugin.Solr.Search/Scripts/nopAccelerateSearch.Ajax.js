﻿$(document).on("keyup", ".npacc-filter-search", function () {

    //http://stackoverflow.com/questions/11083768/after-ajax-call-jquery-function-not-working-properly

    //Search filter
    SearchFilter($(this).val(), $(this).attr('id'));

    //Store text in browser
    WebStorageFilter($(this).val(), $(this).attr('id'), true);

});
$(document).ready(function () {
    ClearWebStorageFilter();

    //Lazy Loading
    $("img.lazy").show().lazyload({
        effect: "fadeIn"
    });

});

//Display text of particular filter search text box
function DisplayFilterSearchBoxValue() {
    $(".npacc-filter-search").each(function () {
        WebStorageFilter(null, $(this).attr("id"), false);
    });
}

//Collapse filter 
function SlideUpDown(divId, arrowId) {
    if ($('#' + divId).is(':visible')) {
        $('#' + divId).slideUp("slow");
        $('#' + arrowId).attr('class', 'arrow rotate');
    }
    else {
        $('#' + divId).slideDown("slow");
        $('#' + arrowId).attr('class', 'arrow');
    }

}


//Clear all filter search text from browser
$("#npacc-clearAll").click(function () {
    ClearWebStorageFilter();
});


function callAjax(url) {
    //Show  ajax loader
    $('#npacc-ajax-loading').show();

    $.ajax({
        url: url,
        type: 'POST',
        success: function (result) {
            $('#npacc-search').replaceWith(result);
            $('#npacc-ajax-loading').hide();
            if (($('.pager').find('li').text() == "") && ($('#product-grid').length > 0)) {
                $('#product-grid').jscroll.destroy();
            }
            var n = $("input:checked").length;
            if (n > 0) {
                $('#npacc-clearAll').attr('style', 'display:block;');
            }
            DisplayFilterSearchBoxValue();

            //Lazy Loading
            $("img.lazy").show().lazyload({
                effect: "fadeIn"
            });
            $(window).trigger("scroll");
        }
    });

    //Scroll to top of page
    //ScrollToTop();
    return false;

}

//start: removable tag filters
function prepareSpecificationFilterTags(url) {
    var filterString = '';
    $('ul#tagsList').html(filterString);

    if (url) {
        var queryAttributes = url.split('?')[1];
        queryAttributes = queryAttributes.split('&');
        queryAttributes.forEach(function (specAttr) {
            var repColon = replaceAllString(specAttr, "%3a", ":");
            var repSeperator = replaceAllString(repColon, "%7c", "|");
            var IsSecification = (repSeperator.indexOf("specs=") >= 0);
            var IsCategory = (repSeperator.indexOf("category=") >= 0);
            var IsVendor = (repSeperator.indexOf("vendor=") >= 0);
            var IsManufacturer = (repSeperator.indexOf("manufacturer=") >= 0);
            if ((IsSecification) || (IsCategory) || (IsVendor) || (IsManufacturer)) {
                repSeperator = repSeperator.replace("specs=", "").replace("category=", "").replace("vendor=", "").replace("manufacturer=", "");
                var selOptions = repSeperator.split("||");
                selOptions.forEach(function (tag) {
                    if (tag) {
                        var filterPair = tag;
                        tag = replaceAllString(tag, "+", " ").replace("pa_", "").replace("f_", "").split(':');
                        filterString += '<li><input type="hidden" value="' + filterPair + '" class="filterPair" /><span class="tag" title="Remove This Filter"><span>' + decodeURIComponent(tag[0]) + '</span> : ';
                        if (IsSecification) {
                            filterString += '<span class="sSpecification">' + decodeURIComponent(tag[1]) + '</span><span class="remove">x</span></span></li>';
                        } else if (IsCategory) {
                            filterString += '<span class="sCategory">' + decodeURIComponent(tag[1]) + '</span><span class="remove">x</span></span></li>';
                        } else if (IsVendor) {
                            filterString += '<span class="sVendor">' + decodeURIComponent(tag[1]) + '</span><span class="remove">x</span></span></li>';
                        } else if (IsManufacturer) {
                            filterString += '<span class="sManufacturer">' + decodeURIComponent(tag[1]) + '</span><span class="remove">x</span></span></li>';
                        }
                    }
                });
            } else if (repSeperator.indexOf("stock=exclude_out_of_stock_products") >= 0) {
                var tag = "Exclude Out Of Stock";
                filterString += '<li><span class="tag" title="Remove This Filter"><span>Availability</span> : ';
                filterString += '<span class="sStock">' + tag + '</span><span class="remove">x</span></span></li>';
            } else if (repSeperator.indexOf("stock=include_out_of_stock_products") >= 0) {
                var tag = "Include Out Of Stock";
                filterString += '<li><span class="tag" title="Remove This Filter"><span>Availability</span> : ';
                filterString += '<span class="sStock">' + tag + '</span><span class="remove">x</span></span></li>';
            }
        });

        $('ul#tagsList').append(filterString);
    }
}
function replaceAllString(string, find, replace) {
    //custom funcrion to replace all the occurences of string
    var str = string.replace(new RegExp(escapeRegExp(find), 'g'), replace);
    return str;
}
function escapeRegExp(string) {
    return string.replace(/([.*+?^=!:${}()|\[\]\/\\])/g, "\\$1");
}
function removeParameter(url, parameter) {
    var urlparts = url.split('?');

    if (urlparts.length >= 2) {
        var urlBase = urlparts.shift(); //get first part, and remove from array
        var queryString = urlparts.join("?"); //join it back up

        var prefix = encodeURIComponent(parameter) + '=';
        var pars = queryString.split(/[&;]/g);
        for (var i = pars.length; i-- > 0;)               //reverse iteration as may be destructive
            if (pars[i].lastIndexOf(prefix, 0) !== -1)   //idiom for string.startsWith
                pars.splice(i, 1);
        url = urlBase + '?' + pars.join('&');
    }
    return url;
}
//end: removable tag filters

//Clear all filter search text from browser
function ClearWebStorageFilter() {
    if (typeof (Storage) !== "undefined") {
        sessionStorage.clear();
    }
}
//Store filter search text in browser
function WebStorageFilter(keyword, id, isAjaxRequest) {
    var sessionStorageId = "sessionStorageId-" + id;

    if (!isAjaxRequest) {

        if (typeof (Storage) !== "undefined") {

            if (sessionStorage[sessionStorageId] !== "undefined" && sessionStorage[sessionStorageId] !== "") {
                $("#" + id).val(sessionStorage[sessionStorageId]);
                SearchFilter(sessionStorage[sessionStorageId], id);
            }
        }
    }
    else {
        if (typeof (Storage) !== "undefined") {
            if (sessionStorage[sessionStorageId] !== "undefined" && sessionStorage[sessionStorageId] !== "") {
                sessionStorage[sessionStorageId] = keyword;
            }
            else {
                sessionStorage[sessionStorageId] = "";
                sessionStorage[sessionStorageId] = keyword;
            }
        }
    }
}

//Search in filter
function SearchFilter(keyword, id) {
    var found = false;
    $("#" + id + "-item li").each(function (li) {
        var originalText = $(this).find("span").attr("original");
        var regExp = new RegExp(keyword, 'i');
        if (regExp.test(originalText)) {
            $(this).show();

            //Highlights searched text
            $oldcontent = $(this).find("span").attr("original");
            $(this).find("span").html($oldcontent.replace(regExp.exec(originalText), '<em class="matched">' + regExp.exec(originalText) + '</em>'));

        }
        else {
            $(this).hide();
        }
    });
}

// fix for ie8 printed checkbox bug using jquery
//http://stackoverflow.com/questions/1414748/internet-explorer-8-and-checkbox-css-problem
$('input[type=checkbox]').live('change', function () {
    if ($(this).is(':checked')) {
        $(this).attr('checked', true);
    } else {
        $(this).attr('checked', false);
    }
});

function npAccFiltersPushStateUrl(stateUrl) {
    manualStateChange = false;
    History.pushState({ loadUrl: stateUrl, rand: Math.random() }, document.title, stateUrl);
}

//function called when back and forward button click of any browser
$(function () {
    // history.js
    History.Adapter.bind(window, 'statechange', function () {
        if (manualStateChange == true) {
            var State = History.getState();
            callAjax(State.data.loadUrl);
        }
        manualStateChange = true;
    });
});
