﻿$(document).on("keyup", ".npacc-filter-search", function () {

    //http://stackoverflow.com/questions/11083768/after-ajax-call-jquery-function-not-working-properly

    //Search filter
    SearchFilter($(this).val(), $(this).attr('id'));

    //Store text in browser
    WebStorageFilter($(this).val(), $(this).attr('id'), true);

});
$(document).ready(function () {
    ClearWebStorageFilter();

    //Lazy Loading
    $("img.lazy").show().lazyload({
        effect: "fadeIn"
    });

});

//Display text of particular filter search text box
function DisplayFilterSearchBoxValue() {
    $(".npacc-filter-search").each(function () {
        WebStorageFilter(null, $(this).attr("id"), false);
    });
}

//Collapse filter 
function SlideUpDown(divId, arrowId) {
    if ($('#' + divId).is(':visible')) {
        $('#' + divId).slideUp("slow");
        $('#' + arrowId).attr('class', 'arrow rotate');
    }
    else {
        $('#' + divId).slideDown("slow");
        $('#' + arrowId).attr('class', 'arrow');
    }

}


//Clear all filter search text from browser
$("#npacc-clearAll").click(function () {
    ClearWebStorageFilter();
});


function callAjax(url) {
    //Show  ajax loader
    $('#npacc-ajax-loading').show();

    $.ajax({
        url: url,
        type: 'POST',
        success: function (result) {
            $('#npacc-search').replaceWith(result);
            $('#npacc-ajax-loading').hide();
            DisplayFilterSearchBoxValue();

            //Lazy Loading
            $("img.lazy").show().lazyload({
                effect: "fadeIn"
            });
            $(window).trigger("scroll");
        }
    });

    //Scroll to top of page
    //ScrollToTop();
    return false;

}

//Clear all filter search text from browser
function ClearWebStorageFilter() {
    if (typeof (Storage) !== "undefined") {
        sessionStorage.clear();
    }
}
//Store filter search text in browser
function WebStorageFilter(keyword, id, isAjaxRequest) {
    var sessionStorageId = "sessionStorageId-" + id;

    if (!isAjaxRequest) {

        if (typeof (Storage) !== "undefined") {

            if (sessionStorage[sessionStorageId] !== "undefined" && sessionStorage[sessionStorageId] !== "") {
                $("#" + id).val(sessionStorage[sessionStorageId]);
                SearchFilter(sessionStorage[sessionStorageId], id);
            }
        }
    }
    else {
        if (typeof (Storage) !== "undefined") {
            if (sessionStorage[sessionStorageId] !== "undefined" && sessionStorage[sessionStorageId] !== "") {
                sessionStorage[sessionStorageId] = keyword;
            }
            else {
                sessionStorage[sessionStorageId] = "";
                sessionStorage[sessionStorageId] = keyword;
            }
        }
    }
}

//Search in filter
function SearchFilter(keyword, id) {
    var found = false;
    $("#" + id + "-item li").each(function (li) {
        var originalText = $(this).find("span").attr("original");
        var regExp = new RegExp(keyword, 'i');
        if (regExp.test(originalText)) {
            $(this).show();

            //Highlights searched text
            $oldcontent = $(this).find("span").attr("original");
            $(this).find("span").html($oldcontent.replace(regExp.exec(originalText), '<em class="matched">' + regExp.exec(originalText) + '</em>'));

        }
        else {
            $(this).hide();
        }
    });
}

// fix for ie8 printed checkbox bug using jquery
//http://stackoverflow.com/questions/1414748/internet-explorer-8-and-checkbox-css-problem
$('input[type=checkbox]').live('change', function () {
    if ($(this).is(':checked')) {
        $(this).attr('checked', true);
    } else {
        $(this).attr('checked', false);
    }
});