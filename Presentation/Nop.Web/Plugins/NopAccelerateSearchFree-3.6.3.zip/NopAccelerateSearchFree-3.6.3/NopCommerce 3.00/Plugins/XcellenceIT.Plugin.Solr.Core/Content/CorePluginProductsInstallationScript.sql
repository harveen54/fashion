-- ======================================================================
-- Author:		Krutal Modi
-- Create date: 18-05-2013
-- Updated date: 25-07-2013
-- Description:	Makes all products as pending in Incremental_Solr_Product 
-- ======================================================================
DECLARE @pId int
DECLARE @sId int

Truncate Table Incremental_Solr_Product
	
Insert Into Incremental_Solr_Product (ProductId, SolrStatus, IsDeleted, InTime, StoreId) 
Select p.Id, 1,1,GETDATE(),s.Id From Product as p,Store as s

DECLARE tempCursor CURSOR SCROLL FOR 
select p.Id,sm.StoreId from Product as p
	join StoreMapping as sm on p.Id = sm.EntityId
	join Store as s on sm.StoreId=s.Id
	where p.LimitedToStores=1 and sm.EntityName ='Product'
	

OPEN tempCursor 
FETCH FIRST FROM tempCursor
INTO @pId,@sId

WHILE @@fetch_status = 0   
 BEGIN    
    UPDATE Incremental_Solr_Product SET IsDeleted=0
    WHERE ProductId=@pId AND StoreId=@sId
    
    FETCH NEXT FROM tempCursor
    INTO @pId, @sId;
 END
CLOSE tempCursor

UPDATE Incremental_Solr_Product
Set IsDeleted=0
where ProductId in (Select p.Id from Product as p where p.LimitedToStores=0)

UPDATE Incremental_Solr_Product
Set IsDeleted=1
where ProductId in (Select p.Id from Product as p where p.Published = 0 OR p.Deleted = 1)

DEALLOCATE tempCursor
