﻿-- ======================================================================
-- Author:	Ankita Patel
-- Create date: 05-03-2014
-- Updated date:  10-05-2014
-- Description: Add products to Incremental_Solr_Product when add a new Store
-- ======================================================================

Insert into Incremental_Solr_Product(ProductId, SolrStatus, IsDeleted, InTime, StoreId) 
select p.Id, 1, p.Deleted, GETDATE(),s.Id from  Product p, Store s left join Incremental_Solr_Product isp 
on isp.StoreId = s.Id where isp.StoreId is null


UPDATE Incremental_Solr_Product
Set IsDeleted=1
where ProductId in (Select p.Id from Product as p where p.Published = 0) and StoreId in (Select Top 1 (s.Id) from Store s order by Id desc)